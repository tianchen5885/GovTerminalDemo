将厂商提供的 AAR 放到本目录，例如：

government-device-sdk.aar
fingerprint-algorithm.aar

然后在 app/build.gradle.kts 中添加 implementation(files("libs/xxx.aar"))，
并按 docs/厂商AAR接入说明.md 修改 VendorGovernmentDeviceSdk.kt。
