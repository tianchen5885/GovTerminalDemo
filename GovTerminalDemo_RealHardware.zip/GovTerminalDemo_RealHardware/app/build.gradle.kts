plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.govterminal"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.govterminal"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "1.3-real-hardware-only"

        // 当前 ZAZ 指纹 native 库只有 armeabi/armeabi-v7a；现代 AGP 已不支持 armeabi，
        // 因此工程固定生成 armeabi-v7a APK。目标一体机必须支持 32 位 ARM 应用。
        ndk {
            abiFilters += listOf("armeabi-v7a")
        }
    }


    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")

    // Boya N53/N513 二代身份证芯片读卡 SDK（已放入 app/libs）
    implementation(files("libs/N53N513-release.aar"))
}
