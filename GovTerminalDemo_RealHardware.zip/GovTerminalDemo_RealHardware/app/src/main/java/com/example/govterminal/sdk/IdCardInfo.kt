package com.example.govterminal.sdk

data class IdCardInfo(
    val name: String,
    val sex: String,
    val nation: String,
    val birthday: String,
    val address: String,
    val idNumber: String,
    val issuingAuthority: String,
    val validFrom: String,
    val validTo: String,
    /** 从二代身份证芯片读取出的指纹模板，不是图片/OCR 结果。 */
    val fingerprintTemplates: List<ByteArray>
)
