package com.example.govterminal.sdk

interface GovernmentDeviceSdk {
    @Throws(Exception::class)
    fun init()

    fun readIdCard(callback: IdCardCallback)
    fun cancelReadIdCard()

    fun captureFingerprint(callback: FingerprintCallback)
    fun cancelCaptureFingerprint()

    @Throws(Exception::class)
    fun compareFingerprint(idCardTemplate: ByteArray, liveTemplate: ByteArray): Int

    fun release()
}

interface IdCardCallback {
    fun onSuccess(cardInfo: IdCardInfo)
    fun onNoCard()
    fun onTimeout()
    fun onDeviceDisconnected()
    fun onError(code: Int, message: String)
}

interface FingerprintCallback {
    fun onSuccess(template: ByteArray)
    fun onTimeout()
    fun onCaptureFailed(code: Int, message: String)
    fun onDeviceDisconnected()
}
