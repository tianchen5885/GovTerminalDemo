package com.example.govterminal

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.govterminal.sdk.FingerprintCallback
import com.example.govterminal.sdk.GovernmentDeviceSdk
import com.example.govterminal.sdk.IdCardCallback
import com.example.govterminal.sdk.IdCardInfo
import com.example.govterminal.sdk.VendorGovernmentDeviceSdk

class MainActivity : AppCompatActivity() {

    private lateinit var btnReadIdCard: Button
    private lateinit var btnVerifyFingerprint: Button
    private lateinit var tvResult: TextView
    private lateinit var deviceSdk: GovernmentDeviceSdk

    @Volatile private var currentCard: IdCardInfo? = null
    @Volatile private var readingCard = false
    @Volatile private var capturingFingerprint = false

    private val fingerprintMatchThreshold = 60

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnReadIdCard = findViewById(R.id.btnReadIdCard)
        btnVerifyFingerprint = findViewById(R.id.btnVerifyFingerprint)
        tvResult = findViewById(R.id.tvResult)

        // 纯真机版本：仅使用真实 Boya + ZAZ 厂商 SDK。
        deviceSdk = VendorGovernmentDeviceSdk(this)

        initHardware()
        btnReadIdCard.setOnClickListener { readIdCard() }
        btnVerifyFingerprint.setOnClickListener { verifyFingerprint() }
    }

    private fun initHardware() {
        tvResult.text = "正在初始化真实 Boya 身份证模块和 ZAZ 指纹模块..."
        btnReadIdCard.isEnabled = false
        btnVerifyFingerprint.isEnabled = false

        Thread {
            try {
                deviceSdk.init()
                runOnUiThread {
                    if (!canUpdateUi()) return@runOnUiThread
                    tvResult.text = "真实硬件初始化成功。\n请放置二代身份证。"
                    btnReadIdCard.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!canUpdateUi()) return@runOnUiThread
                    tvResult.text = "硬件初始化失败：${e.message ?: "未知异常"}"
                }
            }
        }.start()
    }

    private fun readIdCard() {
        if (readingCard || capturingFingerprint) return
        currentCard = null
        readingCard = true
        btnReadIdCard.isEnabled = false
        btnVerifyFingerprint.isEnabled = false
        tvResult.text = "正在读取二代身份证芯片，请勿移动身份证..."

        deviceSdk.readIdCard(object : IdCardCallback {
            override fun onSuccess(cardInfo: IdCardInfo) {
                runOnUiThread {
                    if (!canUpdateUi()) return@runOnUiThread
                    readingCard = false
                    currentCard = cardInfo
                    btnReadIdCard.isEnabled = true
                    val hasFingerprint = cardInfo.fingerprintTemplates.isNotEmpty()
                    btnVerifyFingerprint.isEnabled = hasFingerprint

                    tvResult.text = buildString {
                        appendLine("身份证芯片读取成功")
                        appendLine()
                        appendLine("姓名：${cardInfo.name}")
                        appendLine("性别：${cardInfo.sex}")
                        appendLine("民族：${cardInfo.nation}")
                        appendLine("出生日期：${cardInfo.birthday}")
                        appendLine("身份证号：${maskIdNumber(cardInfo.idNumber)}")
                        appendLine("地址：${cardInfo.address}")
                        appendLine("签发机关：${cardInfo.issuingAuthority}")
                        appendLine("有效期：${cardInfo.validFrom} - ${cardInfo.validTo}")
                        appendLine()
                        if (hasFingerprint) {
                            val size = cardInfo.fingerprintTemplates.first().size
                            appendLine("身份证芯片指纹数据：已读取")
                            appendLine("原始指纹数据长度：$size bytes")
                            if (size != 512) {
                                appendLine("提示：当前长度不是 ZAZ CCCS 512B 模板，点击核验后会安全阻止直接比对。")
                            }
                        } else {
                            appendLine("身份证芯片未返回指纹数据，不能进行指纹人证核验")
                        }
                    }
                }
            }

            override fun onNoCard() = showCardFailure("未检测到身份证，请重新放置身份证后重试。")
            override fun onTimeout() = showCardFailure("读取身份证超时，请重新放置身份证后重试。")

            override fun onDeviceDisconnected() {
                runOnUiThread {
                    if (!canUpdateUi()) return@runOnUiThread
                    readingCard = false
                    btnReadIdCard.isEnabled = false
                    btnVerifyFingerprint.isEnabled = false
                    tvResult.text = "身份证读卡设备已断开，请检查 USB/串口/模块连接。"
                }
            }

            override fun onError(code: Int, message: String) {
                showCardFailure("身份证读取失败\n错误码：$code\n错误信息：$message")
            }
        })
    }

    private fun showCardFailure(message: String) {
        runOnUiThread {
            if (!canUpdateUi()) return@runOnUiThread
            readingCard = false
            currentCard = null
            btnReadIdCard.isEnabled = true
            btnVerifyFingerprint.isEnabled = false
            tvResult.text = message
        }
    }

    private fun verifyFingerprint() {
        if (readingCard || capturingFingerprint) return
        val card = currentCard ?: run {
            tvResult.text = "请先读取身份证芯片。"
            return
        }
        if (card.fingerprintTemplates.isEmpty()) {
            tvResult.text = "身份证芯片中没有可用指纹数据，无法做人证核验。"
            return
        }

        capturingFingerprint = true
        btnReadIdCard.isEnabled = false
        btnVerifyFingerprint.isEnabled = false
        tvResult.text = "请将手指完整放到指纹采集模块上..."

        deviceSdk.captureFingerprint(object : FingerprintCallback {
            override fun onSuccess(template: ByteArray) {
                Thread {
                    try {
                        val maxScore = card.fingerprintTemplates.maxOf { idTemplate ->
                            deviceSdk.compareFingerprint(idTemplate, template)
                        }
                        val matched = maxScore >= fingerprintMatchThreshold
                        runOnUiThread {
                            if (!canUpdateUi()) return@runOnUiThread
                            capturingFingerprint = false
                            btnReadIdCard.isEnabled = true
                            btnVerifyFingerprint.isEnabled = true
                            tvResult.text = buildString {
                                appendLine(if (matched) "人证核验通过" else "人证核验不通过")
                                appendLine()
                                appendLine("姓名：${card.name}")
                                appendLine("身份证号：${maskIdNumber(card.idNumber)}")
                                appendLine("指纹比对：${if (matched) "匹配" else "不匹配"}")
                                appendLine("比对得分：$maxScore")
                                appendLine("Demo 阈值：$fingerprintMatchThreshold")
                            }
                        }
                    } catch (e: Exception) {
                        showFingerprintFailure("指纹比对未执行/失败：${e.message ?: "未知异常"}")
                    }
                }.start()
            }

            override fun onTimeout() = showFingerprintFailure("指纹采集超时，请重新放置手指后重试。")

            override fun onCaptureFailed(code: Int, message: String) {
                showFingerprintFailure("指纹采集失败\n错误码：$code\n错误信息：$message")
            }

            override fun onDeviceDisconnected() {
                runOnUiThread {
                    if (!canUpdateUi()) return@runOnUiThread
                    capturingFingerprint = false
                    btnReadIdCard.isEnabled = false
                    btnVerifyFingerprint.isEnabled = false
                    tvResult.text = "指纹设备已断开，请检查 USB/供电/模块连接。"
                }
            }
        })
    }

    private fun showFingerprintFailure(message: String) {
        runOnUiThread {
            if (!canUpdateUi()) return@runOnUiThread
            capturingFingerprint = false
            btnReadIdCard.isEnabled = true
            btnVerifyFingerprint.isEnabled = currentCard?.fingerprintTemplates?.isNotEmpty() == true
            tvResult.text = message
        }
    }

    private fun canUpdateUi(): Boolean = !isFinishing && !isDestroyed

    private fun maskIdNumber(idNumber: String): String {
        if (idNumber.length < 10) return idNumber
        return idNumber.take(6) + "********" + idNumber.takeLast(4)
    }

    override fun onDestroy() {
        runCatching { deviceSdk.cancelReadIdCard() }
        runCatching { deviceSdk.cancelCaptureFingerprint() }
        runCatching { deviceSdk.release() }
        super.onDestroy()
    }
}
