package com.example.govterminal

import android.app.Application
import com.boya.n53n513.BoyaReader

class GovTerminalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Boya SDK 官方提供的应用级 Context 初始化入口。
        BoyaReader.setAppContext(this)
    }
}
