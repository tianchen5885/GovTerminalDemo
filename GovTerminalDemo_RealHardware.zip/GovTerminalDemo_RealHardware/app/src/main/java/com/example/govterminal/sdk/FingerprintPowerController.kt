package com.example.govterminal.sdk

import java.io.File
import java.io.FileWriter

/**
 * 定制一体机指纹 USB/5V 上下电控制。
 *
 * 厂家资料给出的节点：/sys/kernel/usb_switch/usbswitch
 * 当前项目按厂家资料约定：
 * - host   = 指纹模块上电 / USB Host 模式
 * - device = 指纹模块下电 / 恢复 Device 模式
 *
 * 注意：写 sysfs 节点通常要求系统应用、平台签名、root 或厂家预置权限。
 */
class FingerprintPowerController(
    private val nodePath: String = DEFAULT_NODE
) {
    companion object {
        const val DEFAULT_NODE = "/sys/kernel/usb_switch/usbswitch"
        const val POWER_ON_VALUE = "host"
        const val POWER_OFF_VALUE = "device"
    }

    @Volatile
    var isPoweredOn: Boolean = false
        private set

    fun powerOn() {
        writeNode(POWER_ON_VALUE)
        isPoweredOn = true
    }

    fun powerOff() {
        writeNode(POWER_OFF_VALUE)
        isPoweredOn = false
    }

    private fun writeNode(value: String) {
        val node = File(nodePath)
        if (!node.exists()) {
            throw IllegalStateException("指纹上下电节点不存在：$nodePath")
        }
        if (!node.canWrite()) {
            throw IllegalStateException(
                "没有权限写指纹上下电节点：$nodePath。" +
                    "请确认 APK 为厂家系统应用/已授予对应 sysfs 写权限。"
            )
        }

        try {
            FileWriter(node, false).use { writer ->
                writer.write(value)
                writer.flush()
            }
        } catch (e: Exception) {
            throw IllegalStateException(
                "写指纹上下电节点失败：$nodePath <- $value，${e.message ?: e.javaClass.simpleName}",
                e
            )
        }
    }
}
