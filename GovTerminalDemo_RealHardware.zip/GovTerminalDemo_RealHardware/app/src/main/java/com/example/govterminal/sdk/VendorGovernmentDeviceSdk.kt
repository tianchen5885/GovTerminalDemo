package com.example.govterminal.sdk

import android.app.Activity
import android.util.Base64
import com.IDWORLD.Interface
import com.IDWORLD.LAPI
import com.boya.n53n513.BoyaErr
import com.boya.n53n513.BoyaReader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 真实厂商 SDK 适配层：
 * 1. Boya N53/N513 负责二代身份证芯片读取；
 * 2. ZAZ/IDWORLD 指纹 SDK 负责现场指纹采集、特征生成和 1:1 比对。
 *
 * 注意：Boya 返回的 fingerPrintBase64 是“身份证芯片指纹数据区原始字节”的 Base64。
 * 当前资料没有证明它一定等同于 ZAZ 的 CCCS 512B 模板，因此 compareFingerprint()
 * 会先做兼容性检查，不满足条件时明确抛错，避免错误比对。
 */
class VendorGovernmentDeviceSdk(
    private val activity: Activity
) : GovernmentDeviceSdk {

    companion object {
        private const val ID_CARD_PATH = "USB"
        private const val CARD_TIMEOUT_MS = 10_000L
        private const val CARD_RETRY_INTERVAL_MS = 120L

        private const val FINGER_TIMEOUT_MS = 10_000L
        private const val FINGER_RETRY_INTERVAL_MS = 80L
        private const val FINGER_TEMPLATE_SIZE = 512

        private const val FINGER_POWER_ON_DELAY_MS = 800L
        private const val FINGER_POWER_OFF_DELAY_MS = 150L
    }

    private val cardExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val powerController = FingerprintPowerController()
    private val fingerExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val cardCancelled = AtomicBoolean(false)
    private val fingerCancelled = AtomicBoolean(false)
    private val released = AtomicBoolean(false)

    @Volatile
    private var boyaReader: BoyaReader? = null

    @Volatile
    private var fingerApi: Interface? = null

    @Volatile
    private var fingerHandle: Int = 0

    override fun init() {
        check(!released.get()) { "SDK 已释放，不能重复初始化" }

        // 身份证模块。Boya 官方示例直接使用 "USB"。
        boyaReader = BoyaReader.openDevice(ID_CARD_PATH)

        // 定制一体机：先把 USB 切到 host，使指纹模块 5V/USB 上电。
        // 厂家资料约定 host=上电，device=下电。
        try {
            powerController.powerOn()
            Thread.sleep(FINGER_POWER_ON_DELAY_MS)

            // 指纹模块需要 Activity，用于 USB 授权。
            val api = Interface(activity)
            val handle = api.F_OpenDevice()
            if (handle <= 0) {
                throw IllegalStateException("指纹设备打开失败，F_OpenDevice=$handle")
            }
            fingerApi = api
            fingerHandle = handle
        } catch (t: Throwable) {
            // 初始化中途失败必须回滚，避免 USB/5V 一直占用。
            runCatching { powerController.powerOff() }
            runCatching { boyaReader?.closeDevice() }
            boyaReader = null
            throw t
        }
    }

    override fun readIdCard(callback: IdCardCallback) {
        val reader = boyaReader
        if (reader == null) {
            callback.onError(101, "身份证读卡器未初始化")
            return
        }

        cardCancelled.set(false)
        cardExecutor.execute {
            val deadline = System.currentTimeMillis() + CARD_TIMEOUT_MS
            var lastError: BoyaErr? = null

            while (!cardCancelled.get() && !released.get()) {
                if (System.currentTimeMillis() >= deadline) {
                    // 连续寻卡/选卡均未成功，业务语义按“无卡”返回；
                    // 通讯层 recvData(103) 则单独按“超时”返回。
                    callback.onNoCard()
                    return@execute
                }

                try {
                    reader.idc_request()
                    reader.idc_select()
                    val info = reader.idc_readInfo(false, true)

                    val rawFinger = info.fingerPrintBase64
                        ?.takeIf { it.isNotBlank() }
                        ?.let { Base64.decode(it, Base64.DEFAULT) }

                    // 当前 Boya SDK 只返回一段“指纹数据区”。在厂商格式未确认之前，
                    // 作为一个原始模板块保存；不要擅自按固定偏移拆成两枚指纹。
                    val templates = if (rawFinger != null && rawFinger.isNotEmpty()) {
                        listOf(rawFinger)
                    } else {
                        emptyList()
                    }

                    callback.onSuccess(
                        IdCardInfo(
                            name = info.name.orEmpty(),
                            sex = info.sex.orEmpty(),
                            nation = info.nation.orEmpty(),
                            birthday = info.birthDate.orEmpty(),
                            address = info.address.orEmpty(),
                            idNumber = info.idno.orEmpty(),
                            issuingAuthority = info.issue.orEmpty(),
                            validFrom = info.effectDate.orEmpty(),
                            validTo = info.expireDate.orEmpty(),
                            fingerprintTemplates = templates
                        )
                    )
                    return@execute
                } catch (e: BoyaErr) {
                    lastError = e
                    when (e.code) {
                        100 -> {
                            callback.onError(e.code, "Boya USB 权限不足：${e.info ?: e.message}")
                            return@execute
                        }
                        101 -> {
                            callback.onError(e.code, "身份证读卡器未打开：${e.info ?: e.message}")
                            return@execute
                        }
                        103 -> {
                            // Boya：接收数据失败。对读卡交互优先作为通讯超时处理。
                            callback.onTimeout()
                            return@execute
                        }
                        102, 106, 107, 110, 202, 203 -> {
                            callback.onDeviceDisconnected()
                            return@execute
                        }
                        else -> {
                            // request/select 在“无卡”状态下通常也会抛厂商异常。
                            // 先持续轮询，到超时时再区分为“无卡/超时”。
                            Thread.sleep(CARD_RETRY_INTERVAL_MS)
                        }
                    }
                } catch (t: Throwable) {
                    callback.onError(-1, "身份证读取异常：${t.message ?: t.javaClass.simpleName}")
                    return@execute
                }
            }

            if (cardCancelled.get()) {
                // 主动取消时不回调错误，避免 Activity 销毁后继续更新 UI。
                return@execute
            }

            if (lastError != null) {
                callback.onNoCard()
            } else {
                callback.onTimeout()
            }
        }
    }

    override fun cancelReadIdCard() {
        cardCancelled.set(true)
    }

    override fun captureFingerprint(callback: FingerprintCallback) {
        val api = fingerApi
        val handle = fingerHandle
        if (api == null || handle <= 0) {
            callback.onDeviceDisconnected()
            return
        }

        fingerCancelled.set(false)
        fingerExecutor.execute {
            val image = ByteArray(LAPI.IMAGE_SIZE)
            val template = ByteArray(FINGER_TEMPLATE_SIZE)
            val deadline = System.currentTimeMillis() + FINGER_TIMEOUT_MS

            while (!fingerCancelled.get() && !released.get()) {
                if (System.currentTimeMillis() >= deadline) {
                    callback.onTimeout()
                    return@execute
                }

                try {
                    when (val imageRet = api.F_GetImage(handle, image)) {
                        1 -> {
                            val createRet = api.F_CreateTemplate(handle, image, template)
                            when {
                                createRet > 0 -> {
                                    callback.onSuccess(template.copyOf())
                                    return@execute
                                }
                                createRet == -100 -> {
                                    callback.onDeviceDisconnected()
                                    return@execute
                                }
                                createRet == -101 -> Thread.sleep(30L)
                                else -> {
                                    callback.onCaptureFailed(createRet, "指纹特征生成失败")
                                    return@execute
                                }
                            }
                        }
                        -100 -> {
                            callback.onDeviceDisconnected()
                            return@execute
                        }
                        -101 -> Thread.sleep(30L)
                        else -> Thread.sleep(FINGER_RETRY_INTERVAL_MS)
                    }
                } catch (t: Throwable) {
                    callback.onCaptureFailed(-1, "指纹采集异常：${t.message ?: t.javaClass.simpleName}")
                    return@execute
                }
            }
        }
    }

    override fun cancelCaptureFingerprint() {
        fingerCancelled.set(true)
    }

    override fun compareFingerprint(idCardTemplate: ByteArray, liveTemplate: ByteArray): Int {
        val api = fingerApi ?: throw IllegalStateException("指纹 SDK 未初始化")
        val handle = fingerHandle
        check(handle > 0) { "指纹设备已断开" }
        require(liveTemplate.size == FINGER_TEMPLATE_SIZE) {
            "现场指纹模板长度异常：${liveTemplate.size}，预期 $FINGER_TEMPLATE_SIZE"
        }

        // 当前 Java/JNI 暴露的是 CompareCCCSTemplates。
        // 未确认身份证芯片模板格式时，不能把任意长度原始数据直接送入 native，
        // 否则可能产生错误结果甚至触发 native 崩溃。
        require(idCardTemplate.size == FINGER_TEMPLATE_SIZE) {
            "身份证芯片指纹原始数据长度=${idCardTemplate.size} bytes，" +
                "与 ZAZ CCCS 512-byte 模板不一致。需要厂家确认模板格式/转换接口后才能比对。"
        }

        val score = api.F_CompareTemplates(handle, idCardTemplate, liveTemplate)
        if (score == -100) throw IllegalStateException("指纹设备已断开")
        if (score == -101) throw IllegalStateException("指纹 SDK 正忙")
        if (score < 0) throw IllegalStateException("指纹比对失败，返回值=$score")
        return score
    }

    override fun release() {
        if (!released.compareAndSet(false, true)) return

        cardCancelled.set(true)
        fingerCancelled.set(true)

        runCatching {
            val api = fingerApi
            val handle = fingerHandle
            if (api != null && handle > 0) {
                api.F_CloseDevice(handle)
            }
        }
        fingerHandle = 0
        fingerApi = null

        // 先关闭指纹 USB 句柄，再切回 device/下电。
        runCatching { Thread.sleep(FINGER_POWER_OFF_DELAY_MS) }
        runCatching { powerController.powerOff() }

        runCatching { boyaReader?.closeDevice() }
        boyaReader = null

        cardExecutor.shutdownNow()
        fingerExecutor.shutdownNow()
    }
}
