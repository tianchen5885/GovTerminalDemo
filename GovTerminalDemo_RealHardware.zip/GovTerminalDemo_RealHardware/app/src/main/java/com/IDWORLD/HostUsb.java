package com.IDWORLD;

import java.util.HashMap;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.util.Log;

public class HostUsb {
    private static final String TAG = "OpenHostUsb";
    private static final boolean D = false;
    private static final String ACTION_USB_PERMISSION = "com.IDWORLD.USB_PERMISSION";
    private Context context = null;
    private UsbManager mDevManager = null;
    private UsbInterface intf = null;
    private UsbDeviceConnection connection = null;
    private UsbDevice device = null;
    private boolean receiverRegistered = false;

    private int m_nEPOutSize = 2048;
    private int m_nEPInSize = 2048;
    private byte[] m_abyTransferBuf = new byte[2048];

    UsbEndpoint endpoint_IN = null;
    UsbEndpoint endpoint_OUT = null;
    UsbEndpoint endpoint_INT = null;
    UsbEndpoint curEndpoint = null;

    private  static void writeLog(String fileName,String content) {
        Log.e(TAG,content);
    }
    public HostUsb() {    }
    public boolean AuthorizeDevice(Context paramContext, int VID, int PID) {
        context = paramContext;
        mDevManager = ((UsbManager) context.getSystemService(Context.USB_SERVICE));
        HashMap<String, UsbDevice> deviceList = mDevManager.getDeviceList();
        if (D) writeLog(TAG, "AuthorizeDevice --------------------- news:" + "mDevManager");
        for (UsbDevice tdevice : deviceList.values()) {
            if (D) writeLog(TAG, "AuthorizeDevice --------------------- news:" + tdevice);
            if (D)
                writeLog(TAG, "news:" + "usb VID:" + tdevice.getVendorId() + "  PID:" + tdevice.getProductId());
            if (tdevice.getVendorId() == VID && (tdevice.getProductId() == PID)) {
                boolean hasPermission = mDevManager.hasPermission(tdevice);
                if (!hasPermission) {
                    Intent permissionAction = new Intent(ACTION_USB_PERMISSION);
                    permissionAction.setPackage(context.getPackageName());
                    int pendingFlags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                            ? PendingIntent.FLAG_MUTABLE : 0;
                    PendingIntent permissionIntent = PendingIntent.getBroadcast(
                            context, 0, permissionAction, pendingFlags);
                    IntentFilter filter = new IntentFilter();
                    filter.addAction(ACTION_USB_PERMISSION);
                    filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
                    if (!receiverRegistered) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            context.registerReceiver(mUsbReceiver, filter, Context.RECEIVER_EXPORTED);
                        } else {
                            context.registerReceiver(mUsbReceiver, filter);
                        }
                        receiverRegistered = true;
                    }
                    mDevManager.requestPermission(tdevice, permissionIntent);
                    return true;
                } else {
                    device = tdevice;
                    if (D) writeLog(TAG, "permission denied for device " + device);
                    return true;
                }
            }
        }
        return false;
    }
    private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (context) {
                    device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            if (D) writeLog(TAG, "Authorize permission " + device);
                            if (D)
                                writeLog(TAG, "BroadcastReceiver onReceive -------------------------- ok");
                        } else {
                            if (D)
                                writeLog(TAG, "BroadcastReceiver onReceive -------------------------- dev = null");
                        }
                    } else {
                        if (D) writeLog(TAG, "permission denied for device " + device);
                        if (D)
                            writeLog(TAG, "BroadcastReceiver onReceive ------------------------- permission denied");
                    }
                }
            }
        }
    };
    public boolean WaitForInterfaces() {
        int timeover = 0;
        while (device == null) {
            timeover++;
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            if (timeover > 1000)
                return false;
        }
        return true;
    }
    public int OpenDeviceInterfaces() {
        UsbDevice mDevice = device;
        // Log.d(TAG, "setDevice " + mDevice);
        int fd = -1;
        if (mDevice == null)
            return -1;
        connection = mDevManager.openDevice(mDevice);
        if (!connection.claimInterface(mDevice.getInterface(0), true))
            return -1;
        if (mDevice.getInterfaceCount() < 1)
            return -1;
        intf = mDevice.getInterface(0);
        if (intf.getEndpointCount() == 0)
            return -1;
        for (int i = 0; i < intf.getEndpointCount(); i++) {
            if (intf.getEndpoint(i).getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (intf.getEndpoint(i).getDirection() == UsbConstants.USB_DIR_IN) {
                    endpoint_IN = intf.getEndpoint(i);
                } else if (intf.getEndpoint(i).getDirection() == UsbConstants.USB_DIR_OUT) {
                    endpoint_OUT = intf.getEndpoint(i);
                }
            } else if (intf.getEndpoint(i).getType() == UsbConstants.USB_ENDPOINT_XFER_INT) {
                endpoint_INT = intf.getEndpoint(i);
            } else {
                if (D) writeLog(TAG, "Not Endpoint or other Endpoint ");
            }
        }
        curEndpoint = intf.getEndpoint(0);
        if ((connection != null)) {
            if (D) writeLog(TAG, "open connection success!");
            fd = connection.getFileDescriptor();
            if (D) writeLog(TAG, "fd = " + fd);
            return fd;
        } else {
            if (D) writeLog(TAG, "finger device open connection FAIL");
            return -1;
        }
    }

    public void CloseDeviceInterface() {
        if (connection != null) {
            if (intf != null) {
                connection.releaseInterface(intf);
            }
            connection.close();
            connection = null;
        }
        if (receiverRegistered && context != null) {
            try {
                context.unregisterReceiver(mUsbReceiver);
            } catch (Exception ignored) {
            }
            receiverRegistered = false;
        }
        device = null;
    }

    public boolean USBBulkSend(byte[] pBuf, int nLen, int nTimeOut) {
        int i, n, r, w_nRet;
        n = nLen / m_nEPOutSize;
        r = nLen % m_nEPOutSize;
        for (i = 0; i < n; i++) {
            System.arraycopy(pBuf, i * m_nEPOutSize, m_abyTransferBuf, 0, m_nEPOutSize);
            w_nRet = connection.bulkTransfer(endpoint_OUT, m_abyTransferBuf, m_nEPOutSize, nTimeOut);
            if (w_nRet != m_nEPOutSize) {
                if (D)
                    writeLog(TAG, "USBBulkSend -------------------------------------\n bulkTransfer failure ");
                return false;
            }
        }
        if (r > 0) {
            System.arraycopy(pBuf, i * m_nEPOutSize, m_abyTransferBuf, 0, r);
            w_nRet = connection.bulkTransfer(endpoint_OUT, m_abyTransferBuf, r, nTimeOut);
            if (w_nRet != r) {
                if (D)
                    writeLog(TAG, "USBBulkSend -------------------------------------\n bulkTransfer failure ");
                return false;
            }
        }

        return true;
    }
    public boolean USBBulkReceive(byte[] pBuf, int nLen, int nTimeOut) {
        int i, n, r, w_nRet;
        n = nLen / m_nEPInSize;
        r = nLen % m_nEPInSize;
        for (i = 0; i < n; i++) {
            w_nRet = connection.bulkTransfer(endpoint_IN, m_abyTransferBuf, m_nEPInSize, nTimeOut);
            if (w_nRet != m_nEPInSize) {
                if (D)
                    writeLog(TAG, "USBBulkReceive -------------------------------------\n bulkTransfer failure ");
                return false;// w_nRet = connection.bulkTransfer(endpoint_IN,
                // m_abyTransferBuf, m_nEPInSize,
                // nTimeOut);//i--;//
            }
            System.arraycopy(m_abyTransferBuf, 0, pBuf, i * m_nEPInSize, m_nEPInSize);
        }
        if (r > 0) {
            w_nRet = connection.bulkTransfer(endpoint_IN, m_abyTransferBuf, r, nTimeOut);
            if (w_nRet != r) {
                if (D)
                    writeLog(TAG, "USBBulkReceive -------------------------------------\n bulkTransfer failure ");
                // w_nRet = connection.bulkTransfer(endpoint_IN,
                // m_abyTransferBuf, r, nTimeOut);
                return false;
            }
            System.arraycopy(m_abyTransferBuf, 0, pBuf, i * m_nEPInSize, r);
        }
        return true;
    }


}
