﻿# 真实 SDK 接入分析

## Boya N53/N513

官方包：`N53N513-release.aar`

核心类：

```java
com.boya.n53n513.BoyaReader
com.boya.n53n513.IDChinaInfo
com.boya.n53n513.BoyaErr
```

核心调用：

```java
BoyaReader.setAppContext(application);
BoyaReader reader = BoyaReader.openDevice("USB");
reader.idc_request();
reader.idc_select();
IDChinaInfo info = reader.idc_readInfo(false, true);
reader.closeDevice();
```

`IDChinaInfo.fingerPrintBase64` 是芯片指纹数据区的 Base64。

通过字节码确认，`idc_readInfo(photo, fingerPrint)` 会从设备响应头读取：

- 身份信息区长度
- 照片区长度
- 指纹区长度

随后对指纹区执行 `Arrays.copyOfRange(...)`，再直接 `Base64.encodeToString(...)`。

因此它不是 OCR 结果，也不是 Boya 转换后的 ZAZ CCCS 特征。

## ZAZ / IDWORLD 指纹

核心类：

```java
com.IDWORLD.Interface
com.IDWORLD.LAPI
com.IDWORLD.HostUsb
```

USB VID/PID：

```text
VID = 0x0483
PID = 0x5710
```

图像：

```text
256 x 360
```

现场采集：

```java
Interface api = new Interface(activity);
int handle = api.F_OpenDevice();
byte[] image = new byte[LAPI.IMAGE_SIZE];
byte[] template = new byte[512];
api.F_GetImage(handle, image);
api.F_CreateTemplate(handle, image, template);
```

比对：

```java
int score = api.F_CompareTemplates(handle, templateA, templateB);
```

返回相似度 0~100。

Java 封装特殊返回值：

```text
-100 设备离线/未打开
-101 SDK busy
```

## Android 12+ 兼容修改

原始 `HostUsb.java` 使用：

```java
PendingIntent.getBroadcast(..., 0)
context.registerReceiver(receiver, filter)
```

新版工程已补充：

- Android 12+ `PendingIntent.FLAG_MUTABLE`
- Android 13+ 动态 Receiver flags
- permission Intent 限定当前 package

## 当前待真机验证

1. Boya 实际返回的身份证芯片指纹区长度。
2. 指纹区是否是 512B CCCS，还是居民身份证标准指纹数据结构/多枚模板组合。
3. `/sys/kernel/usb_switch/usbswitch` 中 `host/device` 在当前固件上的上下电实际语义。
4. 目标一体机是否支持 32 位 `armeabi-v7a` APK。


## 2026-09-11 更新：上下电与 32 位 ABI 已确认

目标一体机已确认支持 32 位 APK，因此项目固定 `armeabi-v7a`。

指纹模块上下电已正式接入：

```text
init()
  -> 写 /sys/kernel/usb_switch/usbswitch = host
  -> 等待 800 ms
  -> F_OpenDevice()

release()/onDestroy()
  -> F_CloseDevice()
  -> 等待 150 ms
  -> 写 /sys/kernel/usb_switch/usbswitch = device
```

初始化任何一步失败都会尝试写 `device` 做回滚。节点写入失败会作为硬件初始化失败明确显示，而不是继续调用指纹 SDK。
