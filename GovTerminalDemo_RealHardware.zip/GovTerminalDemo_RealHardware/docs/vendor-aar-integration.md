﻿# 厂商 AAR 硬件 SDK 接入说明

## 一、目标

本工程将业务层与厂商硬件 API 隔离。`MainActivity` 只依赖 `GovernmentDeviceSdk`，因此更换不同品牌政务一体机时，通常只需修改 `VendorGovernmentDeviceSdk`。

## 二、必须确认的厂商 API

从厂商 SDK 文档中找到以下能力：

| 工程接口 | 厂商 SDK 常见名称 | 说明 |
|---|---|---|
| `init()` | `init/open/connect/openDevice` | 打开读卡器、指纹设备、算法库 |
| `readIdCard()` | `findCard/selectCard/readCard/readIDCard` | 必须是二代身份证芯片读取 |
| 芯片指纹读取 | `fingerData/fpTemplate/readFinger` | 从身份证芯片取得模板 |
| `captureFingerprint()` | `capture/getFeature/enroll` | 现场采集并得到特征模板 |
| `compareFingerprint()` | `match/compare/verify` | 身份证模板与现场模板 1:1 比对 |
| `cancelReadIdCard()` | `cancel/stopRead` | 停止寻卡或读卡 |
| `cancelCaptureFingerprint()` | `stopCapture/cancelCapture` | 停止采集 |
| `release()` | `close/release/unInit/free` | 关闭设备和算法资源 |

## 三、初始化

推荐在 `VendorGovernmentDeviceSdk.init()` 内完成：

```kotlin
reader.open()
fingerDevice.open()
fingerAlgorithm.init()
```

如果其中任何一步失败，应关闭前面已经成功打开的资源，再抛异常。例如：

```kotlin
val readerResult = reader.open()
check(readerResult == 0) { "身份证模块打开失败：$readerResult" }

try {
    val fingerResult = fingerDevice.open()
    check(fingerResult == 0) { "指纹模块打开失败：$fingerResult" }
} catch (e: Exception) {
    runCatching { reader.close() }
    throw e
}
```

不要初始化一半后直接返回，否则下一次进入页面可能无法重新打开设备。

## 四、身份证芯片读取

厂商返回成功后，应转换为：

```kotlin
IdCardInfo(
    name = ...,
    sex = ...,
    nation = ...,
    birthday = ...,
    address = ...,
    idNumber = ...,
    issuingAuthority = ...,
    validFrom = ...,
    validTo = ...,
    fingerprintTemplates = listOf(...)
)
```

关键要求：`fingerprintTemplates` 必须来自**身份证芯片**。

不要把身份证照片、OCR 结果或现场指纹放入该字段。

若厂商返回两枚指纹，可：

```kotlin
val templates = mutableListOf<ByteArray>()
card.finger1?.let(templates::add)
card.finger2?.let(templates::add)
```

## 五、现场指纹采集

正确目标不是仅获取一张指纹 Bitmap，而是获得算法可比对的模板/特征：

```kotlin
override fun captureFingerprint(callback: FingerprintCallback) {
    fingerDevice.capture(object : VendorCallback {
        override fun onSuccess(feature: ByteArray) {
            callback.onSuccess(feature)
        }
    })
}
```

如果设备只返回原始图像，则必须调用厂商算法的特征提取接口，例如：

```text
指纹图像 -> extractFeature() -> 指纹模板
```

然后才能进入 1:1 比对。

## 六、1:1 指纹比对

业务层会把现场模板分别与身份证芯片中的所有指纹模板比较，并取最高分。

如果厂商 API 返回整数 score：

```kotlin
return fingerAlgorithm.match(idCardTemplate, liveTemplate)
```

如果厂商 API 直接返回 Boolean，则建议修改统一接口，直接返回判定结果，避免人为发明阈值。

若必须使用阈值，请严格依据厂商认证文档/项目规范。

## 七、异常码映射

建议在 Adapter 内把厂商错误码映射为统一回调：

```text
未检测到卡           -> onNoCard()
读卡/寻卡超时         -> onTimeout()
USB/串口断开          -> onDeviceDisconnected()
其他读卡错误          -> onError(code, message)

指纹采集超时          -> onTimeout()
采集质量差/特征失败    -> onCaptureFailed(code, message)
指纹设备断开          -> onDeviceDisconnected()
```

不要把所有错误都映射成“读取失败”，否则现场维护时很难定位问题。

## 八、释放资源

推荐顺序：

```text
1. cancelReadIdCard
2. cancelCaptureFingerprint
3. 关闭身份证读卡器
4. 关闭指纹模块
5. 释放指纹算法库
6. 清空引用/状态
```

`release()` 应尽量做到幂等：调用两次也不应崩溃。

Activity 的 `onDestroy()` 已调用这些方法，所以 Adapter 内必须真正实现关闭。

## 九、AAR 与 SO

如果 AAR 内含 JNI `.so`，确认支持设备 ABI，例如：

```text
arm64-v8a
armeabi-v7a
```

如厂商要求固定 ABI，可在 `android.defaultConfig` 添加：

```kotlin
ndk {
    abiFilters += listOf("arm64-v8a", "armeabi-v7a")
}
```

不要在不知道设备 CPU 和厂商 `.so` 架构时随意限制 ABI。

## 十、可能需要的权限

不同一体机厂商差异很大，可能涉及：

- USB Host
- 厂商系统 Service/Binder 权限
- 串口设备节点权限
- 系统签名权限
- 自定义 permission

这些必须以厂商 Manifest 示例和设备 ROM 要求为准。本 Demo 不擅自加入未知权限。

## 十一、接入后验证清单

- 首次进入页面能成功初始化身份证和指纹硬件。
- 退出 Activity 后立即再次进入，设备仍可正常打开。
- 连续读卡 20 次无资源泄漏、无 Device busy。
- 无卡时提示无卡而不是崩溃。
- 读卡超时后可以再次点击读卡。
- 拔掉硬件后能收到断开错误，UI 不继续显示“采集中”。
- 指纹质量差时能提示采集失败并允许重试。
- 身份证芯片无指纹数据时，第二个按钮不可用。
- 指纹比对在工作线程执行，不阻塞 UI。
- SDK 子线程回调更新页面前使用 `runOnUiThread`。
- `onDestroy()` 后 SDK 不再回调已销毁 Activity 的 UI。
