# 文档索引

本工程为纯真实硬件版本，不包含模拟数据路径。

- `vendor-aar-integration.md`：Boya AAR / 指纹 SDK 集成说明。
- `real-sdk-integration-analysis.md`：真实 SDK 接口分析。
- `build-verification.md`：构建环境与验证说明。

最终人证合一仍需真机确认 Boya 身份证芯片指纹数据格式是否与 ZAZ CCCS 模板兼容。
