﻿# 构建验证说明

本次在受限执行环境中尝试运行：

```bash
./gradlew assembleDebug
```

Gradle Wrapper 需要首次下载：

```text
https://services.gradle.org/distributions/gradle-8.9-bin.zip
```

当前环境无外网 DNS，因此失败于：

```text
java.net.UnknownHostException: services.gradle.org
```

即构建尚未进入 Android/Kotlin 编译阶段，不是源码编译错误。

在正常联网的 Android Studio 中打开项目后，Gradle 会自动下载所需组件并继续 Sync/Build。

建议首次真机验证顺序：

1. Android Studio Sync 成功。
2. 确认设备支持 `armeabi-v7a` 32 位应用。
3. 启动 App，检查 Boya 和 ZAZ 初始化结果。
4. 放身份证，记录页面的“原始指纹数据长度”。
5. 若长度为 512，再进行测试性比对；若不是 512，不要绕过项目中的安全检查。
6. 根据真机结果继续确认身份证芯片指纹模板标准和 5V host/device 节点语义。


## 真机额外检查：指纹上下电

安装后首次启动，如果初始化失败，请优先检查日志/UI 是否提示：

- `指纹上下电节点不存在`：当前固件节点路径不同，需要厂家确认。
- `没有权限写指纹上下电节点`：需要系统应用/平台签名/厂家 SELinux 或 sysfs 权限。
- `F_OpenDevice <= 0`：节点已成功切到 host，但 USB 设备仍未枚举，可适当增加 `FINGER_POWER_ON_DELAY_MS` 或检查硬件连接。
