﻿# GovTerminalDemo - 纯真实硬件版

这是 Kotlin Android 政务一体机项目，**不包含 Mock SDK、不包含张三/示例地址等假数据，也没有切换到模拟模式的开关**。

## 已接入的真实硬件

- 二代身份证：Boya N53/N513，`app/libs/N53N513-release.aar`。
- 指纹模块：ZAZ/IDWORLD，`Interface.java` / `LAPI.java` / `HostUsb.java`。
- 指纹 Native 库：`libbiofp_e_lapi.so`、`libFingerILA.so`。
- APK ABI 固定：`armeabi-v7a`（目标一体机已确认支持 32 位 APK）。

## 实际调用链

### 身份证芯片读取

`BoyaReader.openDevice("USB")` → `idc_request()` → `idc_select()` → `idc_readInfo(false, true)`。

读取的是二代身份证芯片，不使用 OCR，不调用摄像头。

身份证芯片返回的 `fingerPrintBase64` 会 Base64 解码为原始指纹数据并保存到 `IdCardInfo.fingerprintTemplates`。

### 现场指纹

初始化前：

`/sys/kernel/usb_switch/usbswitch <- host` → 等待 800ms → `F_OpenDevice()`。

采集：

`F_GetImage()` → `F_CreateTemplate()` → 生成 512-byte 现场指纹模板。

关闭：

`F_CloseDevice()` → 等待 150ms → `/sys/kernel/usb_switch/usbswitch <- device`。

### 指纹比对

使用 `F_CompareTemplates()` 做 1:1 比对，Demo 判定阈值当前为 60。

**安全限制：** Boya 返回的是身份证芯片“指纹数据区”的原始内容；现有厂商资料尚未证明它一定就是 ZAZ CCCS 512-byte 模板。因此代码只在身份证指纹块恰好为 512 bytes 时允许进入 `F_CompareTemplates()`，其他长度会明确报“模板格式待确认”，不会伪造比对结果，也不会强行送入 native 导致误判或崩溃。

## 生命周期

`MainActivity.onCreate()`：初始化真实 Boya + ZAZ 硬件。

`MainActivity.onDestroy()`：取消读卡 → 取消采集 → `F_CloseDevice()` → 指纹下电 → `BoyaReader.closeDevice()` → 关闭线程池。

## 异常处理

已处理：

- Boya USB 权限不足
- 未检测到身份证
- 读卡超时/通信失败
- 身份证设备断开
- 指纹上下电节点不存在/无写权限
- `F_OpenDevice()` 失败
- 指纹设备断开
- SDK busy
- 指纹采集超时
- 指纹特征生成失败
- 模板长度不兼容
- 指纹比对返回异常

硬件工作在线程池中执行；Activity 更新 UI 时统一使用 `runOnUiThread`。

## 关键文件

- `app/src/main/java/com/example/govterminal/MainActivity.kt`
- `app/src/main/java/com/example/govterminal/sdk/VendorGovernmentDeviceSdk.kt`
- `app/src/main/java/com/example/govterminal/sdk/FingerprintPowerController.kt`
- `app/src/main/java/com/example/govterminal/GovTerminalApplication.kt`
- `app/src/main/java/com/IDWORLD/`
- `app/libs/N53N513-release.aar`
- `app/src/main/jniLibs/armeabi-v7a/libbiofp_e_lapi.so`
- `app/src/main/jniLibs/armeabi-v7a/libFingerILA.so`

## 真机首次验证需要关注

1. `/sys/kernel/usb_switch/usbswitch` 是否允许 APK 写入；无权限需要一体机厂商提供系统/平台签名或 sysfs/SELinux 权限。
2. `F_OpenDevice()` 是否成功。
3. Boya 是否能正常读取身份证基本信息。
4. 页面显示的“身份证芯片指纹原始数据长度”是多少。
5. `F_CreateTemplate()` 是否正常产生现场模板。

其中第 4 项决定最终身份证芯片模板是否能直接由 ZAZ 算法比对，还是需要厂商提供模板拆分/转换接口。

## 重要说明

这个版本不会返回任何模拟身份证或模拟指纹数据。硬件未连接、无权限或初始化失败时，只会显示真实错误信息。
